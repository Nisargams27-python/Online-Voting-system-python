import pandas as pd

# Change this to your Excel filename
file_path = 'session.xlsx'

# Load the Excel file
df = pd.read_excel(file_path)

# Print the content
print(df)
