import pandas as pd

# If the Excel file is in the same folder
df = pd.read_excel("session.xlsx")

# Show content
print(df)
