import pandas as pd
import os
import bcrypt
from datetime import datetime

class Database:
    def __init__(self):
        self.data_dir = 'data'
        self.images_dir = 'images'
        self.candidates_file = os.path.join(self.data_dir, 'candidates.xlsx')
        self.voters_file = os.path.join(self.data_dir, 'voters.xlsx')
        self.votes_file = os.path.join(self.data_dir, 'votes.xlsx')
        self.registration_file = os.path.join(self.data_dir, 'registration.xlsx')
        self.session_file = "data/session.xlsx"

        self.create_directories()
        self.initialize_files()

    def create_directories(self):
        os.makedirs(self.data_dir, exist_ok=True)
        os.makedirs(self.images_dir, exist_ok=True)

    def initialize_files(self):
        # Candidates file
        if not os.path.exists(self.candidates_file):
            df = pd.DataFrame(columns=['id', 'name', 'post', 'photo_path', 'symbol_path', 'votes'])
            df.to_excel(self.candidates_file, index=False)

        # Voters file
        if not os.path.exists(self.voters_file):
            df = pd.DataFrame(columns=['voter_id', 'password_hash', 'has_voted'])
            df.to_excel(self.voters_file, index=False)

        # Votes file
        if not os.path.exists(self.votes_file):
            df = pd.DataFrame(columns=['voter_id', 'candidate_id', 'timestamp'])
            df.to_excel(self.votes_file, index=False)

        # Registration file
        if not os.path.exists(self.registration_file):
            df = pd.DataFrame(columns=['voter_id', 'full_name', 'email', 'registration_date'])
            df.to_excel(self.registration_file, index=False)

        # Session file (ensure datetime columns)
        if not os.path.exists(self.session_file):
            df = pd.DataFrame({
                'start_time': pd.Series([pd.NaT], dtype='datetime64[ns]'),
                'end_time': pd.Series([pd.NaT], dtype='datetime64[ns]')
            })
            df.to_excel(self.session_file, index=False)
        else:
            df = pd.read_excel(self.session_file)
            if df.empty:
                df = pd.DataFrame({
                    'start_time': pd.Series([pd.NaT], dtype='datetime64[ns]'),
                    'end_time': pd.Series([pd.NaT], dtype='datetime64[ns]')
                })
                df.to_excel(self.session_file, index=False)

    # --- Candidate Methods ---
    def add_candidate(self, name, post, photo_path, symbol_path):
        df = pd.read_excel(self.candidates_file)
        if name in df['name'].values:
            return False
        new_id = 1 if len(df) == 0 else df['id'].max() + 1
        new_row = pd.DataFrame({
            'id': [new_id],
            'name': [name],
            'post': [post],
            'photo_path': [photo_path],
            'symbol_path': [symbol_path],
            'votes': [0]
        })
        df = pd.concat([df, new_row], ignore_index=True)
        df.to_excel(self.candidates_file, index=False)
        return True

    def get_candidates(self):
        return pd.read_excel(self.candidates_file)

    def update_candidate(self, candidate_id, name, post):
        df = pd.read_excel(self.candidates_file)
        mask = df['id'] == candidate_id
        df.loc[mask, 'name'] = name
        df.loc[mask, 'post'] = post
        df.to_excel(self.candidates_file, index=False)

    def delete_candidate(self, candidate_id):
        df = pd.read_excel(self.candidates_file)
        df = df[df['id'] != candidate_id]
        df.to_excel(self.candidates_file, index=False)

    # --- Voter Methods ---
    def add_voter(self, voter_id, password, name, email):
        voters_df = pd.read_excel(self.voters_file)
        reg_df = pd.read_excel(self.registration_file)
        if str(voter_id) in voters_df['voter_id'].astype(str).values:
            return False
        pw_hash = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
        new_voter = pd.DataFrame({'voter_id': [str(voter_id)], 'password_hash': [pw_hash], 'has_voted': [False]})
        voters_df = pd.concat([voters_df, new_voter], ignore_index=True)
        voters_df.to_excel(self.voters_file, index=False)
        new_reg = pd.DataFrame({
            'voter_id': [str(voter_id)],
            'full_name': [name],
            'email': [email],
            'registration_date': [datetime.now()]
        })
        reg_df = pd.concat([reg_df, new_reg], ignore_index=True)
        reg_df.to_excel(self.registration_file, index=False)
        return True

    def verify_voter(self, voter_id, password):
        voters_df = pd.read_excel(self.voters_file)
        voters_df['voter_id'] = voters_df['voter_id'].astype(str)
        voter = voters_df[voters_df['voter_id'] == str(voter_id)]
        if voter.empty:
            return False
        stored_hash = voter.iloc[0]['password_hash']
        try:
            return bcrypt.checkpw(password.encode(), stored_hash.encode())
        except Exception as e:
            print("Error in verify_voter:", e)
            return False

    def has_voted(self, voter_id):
        voters_df = pd.read_excel(self.voters_file)
        voters_df['voter_id'] = voters_df['voter_id'].astype(str)
        voter = voters_df[voters_df['voter_id'] == str(voter_id)]
        if voter.empty:
            return False
        return voter.iloc[0]['has_voted']

    def record_vote(self, voter_id, candidate_id):
        try:
            votes_df = pd.read_excel(self.votes_file)
            new_vote = pd.DataFrame({
                'voter_id': [str(voter_id)],
                'candidate_id': [candidate_id],
                'timestamp': [datetime.now()]
            })
            votes_df = pd.concat([votes_df, new_vote], ignore_index=True)
            votes_df.to_excel(self.votes_file, index=False)
            # Update candidate votes
            df = pd.read_excel(self.candidates_file)
            df.loc[df['id'] == candidate_id, 'votes'] += 1
            df.to_excel(self.candidates_file, index=False)
            # Mark voter voted
            voters_df = pd.read_excel(self.voters_file)
            voters_df['voter_id'] = voters_df['voter_id'].astype(str)
            voters_df.loc[voters_df['voter_id'] == str(voter_id), 'has_voted'] = True
            voters_df.to_excel(self.voters_file, index=False)
            return True
        except Exception as e:
            print("Error in record_vote:", e)
            return False

    def delete_voter(self, voter_id):
        voters_df = pd.read_excel(self.voters_file)
        voters_df = voters_df[voters_df['voter_id'] != str(voter_id)]
        voters_df.to_excel(self.voters_file, index=False)
        votes_df = pd.read_excel(self.votes_file)
        votes_df = votes_df[votes_df['voter_id'] != str(voter_id)]
        votes_df.to_excel(self.votes_file, index=False)
        reg_df = pd.read_excel(self.registration_file)
        reg_df = reg_df[reg_df['voter_id'] != str(voter_id)]
        reg_df.to_excel(self.registration_file, index=False)

    # --- Session Methods ---
    def get_voting_status(self):
        """Always re-read session file from disk to ensure accurate status"""
        import pandas as pd
        import os

        if not os.path.exists(self.session_file):
            return 'not_started'

        try:
            df = pd.read_excel(self.session_file)

            # Handle if file empty or columns missing
            if df.empty or 'start_time' not in df.columns:
                return 'not_started'

            start = df.iloc[0].get('start_time')
            end = df.iloc[0].get('end_time')

            if pd.isna(start):
                return 'not_started'
            elif pd.isna(end):
                return 'active'
            else:
                return 'ended'
        except Exception as e:
            print("Error reading session file:", e)
            return 'not_started'

    def start_voting_session(self):
        try:
            df = pd.DataFrame({
                'start_time': pd.Series([pd.Timestamp.now()], dtype='datetime64[ns]'),
                'end_time': pd.Series([pd.NaT], dtype='datetime64[ns]')
            })
            df.to_excel(self.session_file, index=False)
            return True
        except Exception as e:
            print("Error in start_voting_session:", e)
            return False

    def end_voting_session(self):
        try:
            df = pd.read_excel(self.session_file)
            df['end_time'] = pd.to_datetime(df['end_time'], errors='coerce')
            df.loc[0, 'end_time'] = pd.Timestamp.now()
            df.to_excel(self.session_file, index=False)
            return True
        except Exception as e:
            print("Error in end_voting_session:", e)
            return False

    def can_vote(self):
        return self.get_voting_status() == 'active'

    # --- Results & Export ---
    def get_results(self):
        return pd.read_excel(self.candidates_file)

    def export_results(self, filename):
        results = self.get_results()
        results.to_excel(filename, index=False)
