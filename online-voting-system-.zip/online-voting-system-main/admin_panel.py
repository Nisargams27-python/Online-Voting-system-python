import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import pandas as pd
from PIL import Image, ImageTk
import os
import shutil
from datetime import datetime

class AdminPanel:
    def __init__(self, root):
        self.root = root
        self.root.title("Admin Panel - Online Voting System")
        self.root.geometry("1300x800")

        self.data_file = "data/candidates.xlsx"
        self.voter_file = "data/voters.xlsx"
        self.session_file = "data/session.xlsx"

        self.available_posts = [
            "President", "Vice President", "General Secretary",
            "Joint Secretary", "Treasurer", "Cultural Secretary",
            "Sports Secretary"
        ]

        self.photo_images = {}

        # Main frame
        self.main_frame = ttk.Frame(root, padding=10)
        self.main_frame.pack(fill="both", expand=True)

        # Notebook for tabs
        self.tab_control = ttk.Notebook(self.main_frame)
        self.tab_control.pack(fill="both", expand=True)

        # Tabs
        self.candidates_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.candidates_tab, text="Candidates")
        self.setup_candidates_tab()

        self.voters_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.voters_tab, text="Voters")
        self.setup_voters_tab()

        self.results_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.results_tab, text="Results")
        self.setup_results_tab()

        self.session_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.session_tab, text="Session Control")
        self.setup_session_tab()

    # ================= Utility =================
    def browse_file(self, var):
        file = filedialog.askopenfilename(filetypes=[("Image files","*.png *.jpg *.jpeg *.gif")])
        if file:
            var.set(file)

    def copy_image(self, path):
        if not path or not os.path.exists(path):
            return ""
        folder = "data/images"
        os.makedirs(folder, exist_ok=True)
        dest = os.path.join(folder, os.path.basename(path))
        shutil.copy(path, dest)
        return dest

    def clear_candidate_form(self):
        self.id_entry.delete(0, tk.END)
        self.name_entry.delete(0, tk.END)
        self.phone_entry.delete(0, tk.END)
        self.post_combo.set("")
        self.photo_var.set("")
        self.symbol_var.set("")

    def load_image(self, path, size=(50,50)):
        if path and os.path.exists(path):
            img = Image.open(path).resize(size)
            return ImageTk.PhotoImage(img)
        return None

    # ================= Candidates Tab =================
    def setup_candidates_tab(self):
        top_frame = ttk.LabelFrame(self.candidates_tab, text="Add Candidate", padding=20)
        top_frame.pack(fill="x", padx=50, pady=10)

        style = ttk.Style()
        style.configure("Bold.TLabel", font=("TkDefaultFont", 14, "bold"))
        style.configure("TButton", font=("TkDefaultFont", 12, "bold"))

        left_frame = ttk.Frame(top_frame)
        left_frame.grid(row=0, column=0, padx=20, pady=5, sticky="nw")
        right_frame = ttk.Frame(top_frame)
        right_frame.grid(row=0, column=1, padx=40, pady=5, sticky="ne")

        entry_width = 25

        ttk.Label(left_frame, text="ID:", style="Bold.TLabel").grid(row=0, column=0, sticky="w", pady=5)
        self.id_entry = ttk.Entry(left_frame, width=entry_width, font=("TkDefaultFont", 14))
        self.id_entry.grid(row=0, column=1, pady=5, padx=5)
        ttk.Label(left_frame, text="Name:", style="Bold.TLabel").grid(row=1, column=0, sticky="w", pady=5)
        self.name_entry = ttk.Entry(left_frame, width=entry_width, font=("TkDefaultFont", 14))
        self.name_entry.grid(row=1, column=1, pady=5, padx=5)
        ttk.Label(left_frame, text="Phone:", style="Bold.TLabel").grid(row=2, column=0, sticky="w", pady=5)
        self.phone_entry = ttk.Entry(left_frame, width=entry_width, font=("TkDefaultFont", 14))
        self.phone_entry.grid(row=2, column=1, pady=5, padx=5)

        ttk.Label(right_frame, text="Post:", style="Bold.TLabel").grid(row=0, column=0, sticky="w", pady=5)
        self.post_combo = ttk.Combobox(right_frame, values=self.available_posts, state="readonly", width=entry_width, font=("TkDefaultFont", 14))
        self.post_combo.grid(row=0, column=1, pady=5, padx=5)

        ttk.Label(right_frame, text="Photo:", style="Bold.TLabel").grid(row=1, column=0, sticky="w", pady=5)
        self.photo_var = tk.StringVar()
        self.photo_entry = ttk.Entry(right_frame, textvariable=self.photo_var, width=entry_width, font=("TkDefaultFont", 14))
        self.photo_entry.grid(row=1, column=1, pady=5, padx=5)
        ttk.Button(right_frame, text="Browse", command=lambda: self.browse_file(self.photo_var)).grid(row=1, column=2, padx=5)

        ttk.Label(right_frame, text="Symbol:", style="Bold.TLabel").grid(row=2, column=0, sticky="w", pady=5)
        self.symbol_var = tk.StringVar()
        self.symbol_entry = ttk.Entry(right_frame, textvariable=self.symbol_var, width=entry_width, font=("TkDefaultFont", 14))
        self.symbol_entry.grid(row=2, column=1, pady=5, padx=5)
        ttk.Button(right_frame, text="Browse", command=lambda: self.browse_file(self.symbol_var)).grid(row=2, column=2, padx=5)

        ttk.Button(top_frame, text="Add Candidate", command=self.add_candidate).grid(row=1, column=0, columnspan=2, pady=20)

        # Registered Candidates Table
        list_frame = ttk.LabelFrame(self.candidates_tab, text="Registered Candidates", padding=15)
        list_frame.pack(fill="both", expand=True, padx=20, pady=10)

        self.cand_tree = ttk.Treeview(list_frame, columns=("ID", "Name", "Post"), show="tree headings", height=8)
        self.cand_tree.heading("#0", text="Photo")
        self.cand_tree.column("#0", width=60, anchor="center")
        for col in ("ID", "Name", "Post"):
            self.cand_tree.heading(col, text=col)
            self.cand_tree.column(col, width=200, anchor="center")
        self.cand_tree.pack(fill="both", expand=True)
        scrollbar = ttk.Scrollbar(list_frame, orient="vertical", command=self.cand_tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.cand_tree.configure(yscroll=scrollbar.set)

        # Buttons below table, centered
        btn_frame = ttk.Frame(list_frame)
        btn_frame.pack(pady=5)
        btn_frame.place(relx=0.5, rely=1.0, anchor="s")
        ttk.Button(btn_frame, text="Edit Selected", command=self.edit_candidate).grid(row=0, column=0, padx=10)
        ttk.Button(btn_frame, text="Delete Selected", command=self.delete_candidate).grid(row=0, column=1, padx=10)
        ttk.Button(btn_frame, text="Refresh List", command=self.refresh_candidates).grid(row=0, column=2, padx=10)

        self.refresh_candidates()

    # ================= Candidate Methods =================
    def add_candidate(self):
        if not self.id_entry.get() or not self.name_entry.get() or not self.post_combo.get() or not self.phone_entry.get():
            messagebox.showerror("Error", "Please fill ID, Name, Phone, and Post")
            return
        if not self.phone_entry.get().isdigit() or len(self.phone_entry.get()) != 10:
            messagebox.showerror("Error", "Phone number must be 10 digits")
            return
        try:
            df = pd.read_excel(self.data_file)
        except:
            df = pd.DataFrame(columns=["id","name","phone","post","photo_path","symbol_path","votes"])
        if int(self.id_entry.get()) in df['id'].values:
            messagebox.showerror("Error", "ID already exists")
            return
        photo_dest = self.copy_image(self.photo_var.get())
        symbol_dest = self.copy_image(self.symbol_var.get())
        df = pd.concat([df, pd.DataFrame([{
            "id": int(self.id_entry.get()),
            "name": self.name_entry.get(),
            "phone": self.phone_entry.get(),
            "post": self.post_combo.get(),
            "photo_path": photo_dest,
            "symbol_path": symbol_dest,
            "votes": 0
        }])], ignore_index=True)
        df.to_excel(self.data_file, index=False)
        messagebox.showinfo("Success", "Candidate added")
        self.clear_candidate_form()
        self.refresh_candidates()

    def refresh_candidates(self):
        for item in self.cand_tree.get_children():
            self.cand_tree.delete(item)
        self.photo_images.clear()
        try:
            df = pd.read_excel(self.data_file)
        except:
            return
        for _, row in df.iterrows():
            img = self.load_image(row['photo_path'])
            if img:
                self.photo_images[row['id']] = img
            self.cand_tree.insert("", "end", text="", image=img, values=(row['id'], row['name'], row['post']))

    def edit_candidate(self):
        selected = self.cand_tree.selection()
        if not selected:
            messagebox.showerror("Error", "Select a candidate to edit")
            return
        item = self.cand_tree.item(selected[0])
        candidate_id = item['values'][0]
        try:
            df = pd.read_excel(self.data_file)
        except:
            return
        candidate = df[df['id'] == candidate_id].iloc[0]
        self.id_entry.delete(0, tk.END)
        self.id_entry.insert(0, candidate['id'])
        self.name_entry.delete(0, tk.END)
        self.name_entry.insert(0, candidate['name'])
        self.phone_entry.delete(0, tk.END)
        self.phone_entry.insert(0, candidate.get('phone',''))
        self.post_combo.set(candidate['post'])
        self.photo_var.set(candidate['photo_path'])
        self.symbol_var.set(candidate['symbol_path'])

    def delete_candidate(self):
        selected = self.cand_tree.selection()
        if not selected:
            messagebox.showerror("Error", "Select a candidate to delete")
            return
        item = self.cand_tree.item(selected[0])
        candidate_id = item['values'][0]
        if messagebox.askyesno("Confirm Deletion", f"Delete candidate ID {candidate_id}?"):
            try:
                df = pd.read_excel(self.data_file)
            except:
                return
            df = df[df['id'] != candidate_id]
            df.to_excel(self.data_file, index=False)
            messagebox.showinfo("Deleted", "Candidate deleted successfully")
            self.refresh_candidates()

    # ================= Voters Tab =================
    def setup_voters_tab(self):
        frame = ttk.LabelFrame(self.voters_tab, text="Registered Voters", padding=20)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        columns = ("Voter ID", "Name", "Has Voted")
        self.voter_tree = ttk.Treeview(frame, columns=columns, show="headings")
        for col in columns:
            self.voter_tree.heading(col, text=col)
            self.voter_tree.column(col, width=300, anchor="center")
        self.voter_tree.pack(fill="both", expand=True)

        # Buttons below data, centered
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(pady=5)
        btn_frame.place(relx=0.5, rely=1.0, anchor="s")
        ttk.Button(btn_frame, text="Delete Selected", command=self.delete_voter).grid(row=0, column=0, padx=10)
        ttk.Button(btn_frame, text="Refresh List", command=self.refresh_voters).grid(row=0, column=1, padx=10)

        self.refresh_voters()

    def refresh_voters(self):
        for item in self.voter_tree.get_children():
            self.voter_tree.delete(item)
        try:
            df = pd.read_excel(self.voter_file)
        except:
            return
        for _, row in df.iterrows():
            self.voter_tree.insert("", "end", values=(row['voter_id'], row.get('name',''), row['has_voted']))

    def delete_voter(self):
        selected = self.voter_tree.selection()
        if not selected:
            messagebox.showerror("Error", "Select a voter to delete")
            return
        item = self.voter_tree.item(selected[0])
        voter_id = item['values'][0]
        if messagebox.askyesno("Confirm Deletion", f"Delete voter ID {voter_id}?"):
            try:
                df = pd.read_excel(self.voter_file)
            except:
                return
            df = df[df['voter_id'] != voter_id]
            df.to_excel(self.voter_file, index=False)
            messagebox.showinfo("Deleted", "Voter deleted successfully")
            self.refresh_voters()

    # ================= Results Tab =================
    def setup_results_tab(self):
        frame = ttk.LabelFrame(self.results_tab, text="Voting Results", padding=20)
        frame.pack(fill="both", expand=True, padx=20, pady=20)

        columns = ("ID", "Name", "Post", "Votes")
        self.result_tree = ttk.Treeview(frame, columns=columns, show="headings")
        for col in columns:
            self.result_tree.heading(col, text=col)
            self.result_tree.column(col, width=250, anchor="center")
        self.result_tree.pack(fill="both", expand=True)

        # Buttons below table, centered
        btn_frame = ttk.Frame(frame)
        btn_frame.pack(pady=5)
        btn_frame.place(relx=0.5, rely=1.0, anchor="s")
        ttk.Button(btn_frame, text="Refresh Results", command=self.refresh_results).grid(row=0, column=0, padx=10)
        ttk.Button(btn_frame, text="Export Results", command=self.export_results).grid(row=0, column=1, padx=10)

        self.refresh_results()

    def refresh_results(self):
        for item in self.result_tree.get_children():
            self.result_tree.delete(item)
        try:
            df = pd.read_excel(self.data_file)
        except:
            return
        for _, row in df.iterrows():
            self.result_tree.insert("", "end", values=(row['id'], row['name'], row['post'], row['votes']))

    def export_results(self):
        try:
            df = pd.read_excel(self.data_file)
        except:
            messagebox.showerror("Error", "No results available to export")
            return
        filename = f"results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
        df.to_excel(filename, index=False)
        messagebox.showinfo("Exported", f"Results exported as {filename}")

    # ================= Session Tab =================
    def setup_session_tab(self):
        frame = ttk.LabelFrame(self.session_tab, text="Voting Session Control", padding=30)
        frame.pack(fill="x", padx=20, pady=20)

        self.status_label = ttk.Label(frame, text="Current Status: Not Started", font=("TkDefaultFont", 16, "bold"))
        self.status_label.pack(pady=10)

        btn_frame = tk.Frame(frame)
        btn_frame.pack(pady=10)
        self.start_btn = tk.Button(btn_frame, text="START SESSION", font=("TkDefaultFont", 14, "bold"), bg="green", fg="white", command=self.start_session)
        self.start_btn.pack(side="left", padx=20)
        self.end_btn = tk.Button(btn_frame, text="END SESSION", font=("TkDefaultFont", 14, "bold"), bg="red", fg="white", command=self.end_session)
        self.end_btn.pack(side="left", padx=20)

        info_frame = ttk.LabelFrame(self.session_tab, text="Session Information", padding=20)
        info_frame.pack(fill="x", padx=20, pady=20)
        self.start_time_label = ttk.Label(info_frame, text="Start Time: Not started", font=("TkDefaultFont", 12))
        self.start_time_label.pack(pady=5)
        self.end_time_label = ttk.Label(info_frame, text="End Time: Not ended", font=("TkDefaultFont", 12))
        self.end_time_label.pack(pady=5)
        ttk.Button(info_frame, text="Refresh Status", command=self.refresh_session).pack(pady=10)

        self.refresh_session()
    
    def refresh_session(self):
        try:
            df = pd.read_excel(self.session_file)
        except:
            self.status_label.config(text="Current Status: Not Started")
            self.start_time_label.config(text="Start Time: Not started")
            self.end_time_label.config(text="End Time: Not ended")
            return

        if df.empty:
            self.status_label.config(text="Current Status: Not Started")
            return

        row = df.iloc[0]
        start_time = row.get('start_time', 'Not started')
        end_time = row.get('end_time', 'Not ended')
        self.start_time_label.config(text=f"Start Time: {start_time}")
        self.end_time_label.config(text=f"End Time: {end_time}")

        if pd.isna(start_time):
            status = "Not Started"
        elif pd.isna(end_time):
            status = "Active"
        else:
            status = "Ended"

        self.status_label.config(text=f"Current Status: {status}")

    # ================= SESSION CONTROL METHODS =================
    def start_session(self):
        if messagebox.askyesno("Start Session", "Start voting session now?"):
            try:
                df = pd.DataFrame({
                    'start_time': pd.Series([pd.Timestamp.now()], dtype='datetime64[ns]'),
                    'end_time': pd.Series([pd.NaT], dtype='datetime64[ns]')
                })
                df.to_excel(self.session_file, index=False)
                self.refresh_session()
                messagebox.showinfo("Session Started", "Voting session is now active.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to start session: {e}")

    def end_session(self):
        if messagebox.askyesno("End Session", "End voting session now?"):
            try:
                df = pd.read_excel(self.session_file)
                df['end_time'] = pd.to_datetime(df['end_time'], errors='coerce')
                df.loc[0, 'end_time'] = pd.Timestamp.now()
                df.to_excel(self.session_file, index=False)
                self.refresh_session()
                messagebox.showinfo("Session Ended", "Voting session has ended.")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to end session: {e}")


if __name__ == "__main__":
    root = tk.Tk()
    app = AdminPanel(root)
    root.mainloop()

