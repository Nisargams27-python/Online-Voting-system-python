import tkinter as tk
from tkinter import ttk, messagebox
from database import Database
from theme import Theme
from PIL import Image, ImageTk
import os
import re
from datetime import datetime


class VoterInterface:
    def __init__(self, root):
        self.root = root
        self.root.title("Voter Interface - Online Voting System")
        self.db = Database()

        # Create main container
        self.main_frame = ttk.Frame(self.root, padding="50")
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Configure grid weights
        self.root.grid_rowconfigure(0, weight=1)
        self.root.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_rowconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)

        # Create menu bar
        self.create_menu()

        # Initially show login frame
        self.show_login_frame()

    def create_menu(self):
        self.menu_bar = tk.Menu(self.root)
        self.root.config(menu=self.menu_bar)
        self.menu_bar.add_command(label="Home", command=self.show_home_frame)

    # ------------------- LOGIN FRAME -------------------
    def show_login_frame(self):
        for widget in self.main_frame.winfo_children():
            widget.destroy()

        login_frame = ttk.LabelFrame(self.main_frame, text="Voter Login", padding="120")
        login_frame.grid(row=0, column=0, padx=50, pady=30)
        login_frame.grid_columnconfigure(1, weight=1)

        ttk.Label(login_frame, text="Voter ID:").grid(row=0, column=0, padx=3, pady=2)
        self.voter_id_entry = ttk.Entry(login_frame, width=80)
        self.voter_id_entry.grid(row=0, column=1, padx=3, pady=2, sticky=(tk.W, tk.E))
        vcmd = (self.root.register(self.validate_number), '%P')
        self.voter_id_entry.config(validate='key', validatecommand=vcmd)

        ttk.Label(login_frame, text="Password:").grid(row=1, column=0, padx=3, pady=2)
        self.password_entry = ttk.Entry(login_frame, show="•", width=20)
        self.password_entry.grid(row=1, column=1, padx=3, pady=2, sticky=(tk.W, tk.E))

        ttk.Button(login_frame, text="Login", style='Primary.TButton', command=self.login)\
            .grid(row=2, column=0, columnspan=2, pady=8)

        # 🟩 Check session and disable registration if session off
        status = self.db.get_voting_status()
        register_btn = ttk.Button(
            login_frame,
            text="New Voter? Register Here",
            style='Success.TButton',
            command=self.show_registration_frame
        )
        register_btn.grid(row=3, column=0, columnspan=2, pady=3)

        if status != 'active':
            register_btn.state(['disabled'])  # disable button if session off
            ttk.Label(login_frame, text="Registration disabled (Session not active)", foreground=Theme.WARNING)\
                .grid(row=4, column=0, columnspan=2, pady=5)

        login_frame.grid(row=0, column=0, sticky="nsew")
        self.main_frame.grid_rowconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)

    # ------------------- REGISTRATION FRAME -------------------
    def show_registration_frame(self):
        status = self.db.get_voting_status()
        if status != 'active':
            messagebox.showerror("Error", "Voting session is not active. Registration is closed.")
            self.show_login_frame()
            return

        for widget in self.main_frame.winfo_children():
            widget.destroy()

        reg_frame = ttk.LabelFrame(self.main_frame, text="Voter Registration", padding="100")
        reg_frame.grid(row=0, column=0, padx=80, pady=80, sticky=(tk.W, tk.E))
        reg_frame.grid_columnconfigure(1, weight=1)

        ttk.Label(reg_frame, text="Full Name:").grid(row=0, column=0, padx=5, pady=5)
        self.name_entry = ttk.Entry(reg_frame, width=30)
        self.name_entry.grid(row=0, column=1, padx=5, pady=5, sticky=(tk.W, tk.E))

        ttk.Label(reg_frame, text="Date of Birth (DD/MM/YYYY):").grid(row=1, column=0, padx=5, pady=5)
        self.dob_entry = ttk.Entry(reg_frame, width=30)
        self.dob_entry.grid(row=1, column=1, padx=5, pady=5, sticky=(tk.W, tk.E))

        ttk.Label(reg_frame, text="Choose Voter ID:").grid(row=2, column=0, padx=5, pady=5)
        self.reg_voter_id_entry = ttk.Entry(reg_frame, width=30)
        self.reg_voter_id_entry.grid(row=2, column=1, padx=5, pady=5, sticky=(tk.W, tk.E))
        vcmd = (self.root.register(self.validate_number), '%P')
        self.reg_voter_id_entry.config(validate='key', validatecommand=vcmd)

        ttk.Label(reg_frame, text="Password (min 4 chars):").grid(row=3, column=0, padx=5, pady=5)
        self.reg_password_entry = ttk.Entry(reg_frame, show="•", width=30)
        self.reg_password_entry.grid(row=3, column=1, padx=5, pady=5, sticky=(tk.W, tk.E))

        ttk.Label(reg_frame, text="Confirm Password:").grid(row=4, column=0, padx=5, pady=5)
        self.confirm_password_entry = ttk.Entry(reg_frame, show="•", width=30)
        self.confirm_password_entry.grid(row=4, column=1, padx=5, pady=5, sticky=(tk.W, tk.E))

        ttk.Button(reg_frame, text="Register", style='Success.TButton', command=self.register)\
            .grid(row=5, column=0, columnspan=2, pady=15)
        ttk.Button(reg_frame, text="Back to Login", style='Primary.TButton', command=self.show_login_frame)\
            .grid(row=6, column=0, columnspan=2, pady=5)

    # ------------------- HOME FRAME -------------------
    def show_home_frame(self):
        if not hasattr(self, 'current_voter_id'):
            messagebox.showinfo("Info", "Please login first to view live results")
            return

        for widget in self.main_frame.winfo_children():
            widget.destroy()

        home_frame = ttk.LabelFrame(self.main_frame, text="Live Vote Counts", padding="30")
        home_frame.grid(row=0, column=0, padx=30, pady=30, sticky=(tk.W, tk.E, tk.N, tk.S))
        home_frame.grid_rowconfigure(2, weight=1)
        home_frame.grid_columnconfigure(0, weight=1)

        ttk.Label(home_frame, text=f"Welcome, Voter ID: {self.current_voter_id}", style='Header.TLabel')\
            .grid(row=0, column=0, columnspan=2, pady=10)

        status = self.db.get_voting_status()
        status_frame = ttk.Frame(home_frame)
        status_frame.grid(row=1, column=0, columnspan=2, pady=10)

        if status == 'not_started':
            ttk.Label(status_frame, text="Voting has not started yet. Please wait for the admin to begin the session.", foreground=Theme.WARNING)\
                .grid(row=0, column=0, pady=5)
        elif status == 'ended':
            ttk.Label(status_frame, text="Voting has ended. Thank you for your participation!", foreground=Theme.ERROR)\
                .grid(row=0, column=0, pady=5)

        columns = ('ID', 'Name', 'Post', 'Votes')
        self.results_tree = ttk.Treeview(home_frame, columns=columns, show='tree headings', height=10)
        self.results_tree.heading('#0', text='Photo')
        for col in columns:
            self.results_tree.heading(col, text=col)

        self.results_tree.column('#0', width=100, minwidth=100, anchor='center')
        self.results_tree.column('ID', width=50, minwidth=50, anchor='center')
        self.results_tree.column('Name', width=150, minwidth=150)
        self.results_tree.column('Post', width=150, minwidth=150)
        self.results_tree.column('Votes', width=80, minwidth=80, anchor='center')

        self.results_tree.grid(row=2, column=0, columnspan=2, pady=20, sticky=(tk.W, tk.E, tk.N, tk.S))
        scrollbar = ttk.Scrollbar(home_frame, orient=tk.VERTICAL, command=self.results_tree.yview)
        scrollbar.grid(row=2, column=2, sticky=(tk.N, tk.S))
        self.results_tree.configure(yscrollcommand=scrollbar.set)

        ttk.Button(home_frame, text="Refresh Results", style='Primary.TButton', command=self.refresh_results)\
            .grid(row=3, column=0, columnspan=2, pady=15)

        button_frame = ttk.Frame(home_frame)
        button_frame.grid(row=4, column=0, columnspan=2, pady=20)
        if status == 'active':
            has_voted = self.db.has_voted(self.current_voter_id)
            if not has_voted:
                ttk.Button(button_frame, text="Cast Vote", style='Success.TButton', command=self.show_voting_frame)\
                    .grid(row=0, column=0, padx=20)
        ttk.Button(button_frame, text="Logout", style='Error.TButton', command=self.logout)\
            .grid(row=0, column=1, padx=20)

        self.refresh_results()

    # ------------------- VOTING FRAME -------------------
    def show_voting_frame(self):
        if not self.db.can_vote():
            messagebox.showerror("Error", "Voting is not currently active")
            self.show_home_frame()
            return
        if self.db.has_voted(self.current_voter_id):
            messagebox.showinfo("Info", "You have already cast your vote.")
            self.show_home_frame()
            return

        for widget in self.main_frame.winfo_children():
            widget.destroy()

        main_container = ttk.Frame(self.main_frame, padding="5")
        main_container.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        self.main_frame.grid_rowconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(0, weight=1)
        main_container.grid_rowconfigure(2, weight=1)
        main_container.grid_columnconfigure(0, weight=1)

        top_frame = ttk.Frame(main_container)
        top_frame.grid(row=0, column=0, sticky=(tk.W, tk.E), pady=(0, 50))
        top_frame.grid_columnconfigure(1, weight=1)
        ttk.Label(top_frame, text=f"Welcome, Voter ID: {self.current_voter_id}", style='Header.TLabel').grid(row=0, column=0, padx=5)

        ttk.Label(main_container, text="Please select your preferred candidate:", style='Header.TLabel').grid(row=1, column=0, pady=(0, 50))

        canvas = tk.Canvas(main_container, bg=Theme.BACKGROUND, height=500)
        scrollbar = ttk.Scrollbar(main_container, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas, padding="10", style='TFrame')

        def on_frame_configure(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
        scrollable_frame.bind("<Configure>", on_frame_configure)

        window_id = canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")

        def on_canvas_configure(event):
            canvas.itemconfig(window_id, width=event.width)
        canvas.bind('<Configure>', on_canvas_configure)

        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=2, column=0, sticky="nsew")
        scrollbar.grid(row=2, column=1, sticky="ns")
        scrollable_frame.grid_columnconfigure(0, weight=1)

        candidates = self.db.get_candidates()
        for idx, (_, row) in enumerate(candidates.iterrows()):
            candidate_frame = ttk.Frame(scrollable_frame, style='Candidate.TFrame', padding="20")
            candidate_frame.grid(row=idx, column=0, pady=20, sticky="ew", padx=5)
            candidate_frame.grid_columnconfigure(2, weight=1)
            candidate_frame.grid_columnconfigure(3, weight=1)

            try:
                photo_img = Image.open(row['photo_path']).resize((100, 100), Image.Resampling.LANCZOS)
                photo_tk = ImageTk.PhotoImage(photo_img)
                symbol_img = Image.open(row['symbol_path']).resize((60, 60), Image.Resampling.LANCZOS)
                symbol_tk = ImageTk.PhotoImage(symbol_img)

                photo_label = ttk.Label(candidate_frame, image=photo_tk)
                photo_label.image = photo_tk
                photo_label.grid(row=0, column=0, rowspan=2, padx=15)

                symbol_label = ttk.Label(candidate_frame, image=symbol_tk)
                symbol_label.image = symbol_tk
                symbol_label.grid(row=0, column=1, padx=15)
            except:
                ttk.Label(candidate_frame, text="[Photo]").grid(row=0, column=0, padx=15)
                ttk.Label(candidate_frame, text="[Symbol]").grid(row=0, column=1, padx=15)

            info_frame = ttk.Frame(candidate_frame)
            info_frame.grid(row=0, column=2, sticky="ew", padx=15)
            ttk.Label(info_frame, text=row['name'], style='Header.TLabel').grid(row=0, column=0, sticky="w")
            ttk.Label(info_frame, text=f"Post: {row['post']}").grid(row=1, column=0, sticky="w")
            vote_label = ttk.Label(info_frame, text=f"Current Votes: {row['votes']}", style='Header.TLabel')
            vote_label.grid(row=2, column=0, sticky="w")
            candidate_frame.vote_label = vote_label

            ttk.Button(candidate_frame, text="Vote for this Candidate", style='Success.TButton',
                       command=lambda cid=row['id']: self.select_candidate(cid)).grid(row=0, column=3, padx=15, sticky="e")

        button_frame = ttk.Frame(main_container)
        button_frame.grid(row=3, column=0, pady=15)
        ttk.Button(button_frame, text="View Results", style='Primary.TButton', command=self.show_home_frame).grid(row=0, column=0, padx=5)
        ttk.Button(button_frame, text="Logout", style='Error.TButton', command=self.logout).grid(row=0, column=1, padx=5)

    # ------------------- VOTING -------------------
    def select_candidate(self, candidate_id):
        if messagebox.askyesno("Confirm", "Are you sure you want to cast your vote for this candidate?\n\nNote: You cannot change your vote after submission."):
            if self.db.record_vote(self.current_voter_id, candidate_id):
                messagebox.showinfo("Success", "Your vote has been recorded successfully!\nThank you for participating in the election.")
                self.show_home_frame()
            else:
                messagebox.showerror("Error", "Failed to record your vote. Please try again.")

    # ------------------- LOGIN -------------------
    def login(self):
        # 🟩 Added session check
        status = self.db.get_voting_status()
        if status != 'active':
            messagebox.showerror("Error", "Voting session is not active. You cannot login now.")
            return

        voter_id = self.voter_id_entry.get().strip()
        password = self.password_entry.get()
        if not voter_id or not password:
            messagebox.showerror("Error", "Please fill in all fields")
            return
        try:
            voter_id = int(voter_id)
        except ValueError:
            messagebox.showerror("Error", "Voter ID must be a number")
            return

        if self.db.verify_voter(str(voter_id), password):
            self.current_voter_id = str(voter_id)
            status = self.db.get_voting_status()
            has_voted = self.db.has_voted(str(voter_id))
            if status == 'active' and not has_voted:
                self.show_voting_frame()
            else:
                self.show_home_frame()
        else:
            messagebox.showerror("Error", "Invalid voter ID or password")
            self.password_entry.delete(0, tk.END)

    # ------------------- LOGOUT -------------------
    def logout(self):
        self.current_voter_id = None
        self.show_login_frame()

    # ------------------- REGISTRATION -------------------
    def register(self):
        # 🟩 Added session check
        status = self.db.get_voting_status()
        if status != 'active':
            messagebox.showerror("Error", "Voting session is not active. Registration is closed.")
            return

        name = self.name_entry.get().strip()
        dob = self.dob_entry.get().strip()
        voter_id = self.reg_voter_id_entry.get().strip()
        password = self.reg_password_entry.get()
        confirm_password = self.confirm_password_entry.get()

        if not all([name, dob, voter_id, password, confirm_password]):
            messagebox.showerror("Error", "Please fill in all fields")
            return

        if not re.match("^[A-Za-z ]+$", name):
            messagebox.showerror("Error", "Name must contain letters only")
            return

        try:
            datetime.strptime(dob, "%d/%m/%Y")
        except ValueError:
            messagebox.showerror("Error", "Date of birth must be in DD/MM/YYYY format")
            return

        try:
            voter_id = int(voter_id)
        except ValueError:
            messagebox.showerror("Error", "Voter ID must be a number")
            return

        if len(password) < 4:
            messagebox.showerror("Error", "Password must be at least 4 characters")
            return
        if password != confirm_password:
            messagebox.showerror("Error", "Passwords do not match")
            return

        if self.db.add_voter(str(voter_id), password, name, dob):
            messagebox.showinfo("Success", "Registration successful! You can now login to vote.")
            self.show_login_frame()
        else:
            messagebox.showerror("Error", "Voter ID already exists")

    def refresh_results(self):
        for item in self.results_tree.get_children():
            self.results_tree.delete(item)
        candidates = self.db.get_candidates()
        for _, row in candidates.iterrows():
            self.results_tree.insert("", "end", text="", values=(row['id'], row['name'], row['post'], row['votes']))

    def validate_number(self, value):
        return value.isdigit() or value == ""

if __name__ == "__main__":
    root = tk.Tk()
    root.geometry("1100x800")
    VoterInterface(root)
    root.mainloop()  